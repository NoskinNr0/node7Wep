using System.Net.Http.Headers;
using System.Text.Json;
using System.IO;
using System.Net.Http;
using System.Collections.Generic;
using VierraVHome.Models;

namespace VierraVHome.Services;

public class DiscordService
{
    private readonly HttpClient _http = new();
    private string? _tokenOverride;
    private static string TokenFilePath => Path.Combine(Environment.CurrentDirectory, "Data", "Discord", "token.txt");

    private string? GetToken()
    {
        if (!string.IsNullOrWhiteSpace(_tokenOverride)) return _tokenOverride;
        var envToken = Environment.GetEnvironmentVariable("DISCORD_BOT_TOKEN");
        if (!string.IsNullOrWhiteSpace(envToken)) return envToken;
        try
        {
            if (File.Exists(TokenFilePath))
            {
                var fileToken = File.ReadAllText(TokenFilePath).Trim();
                if (!string.IsNullOrWhiteSpace(fileToken)) return fileToken;
            }
        }
        catch { }
        return null;
    }

    public void SetToken(string token, bool persistToFile = true)
    {
        _tokenOverride = token?.Trim();
        if (persistToFile && !string.IsNullOrWhiteSpace(_tokenOverride))
        {
            Directory.CreateDirectory(Path.GetDirectoryName(TokenFilePath)!);
            File.WriteAllText(TokenFilePath, _tokenOverride);
        }
    }

    public bool HasToken()
    {
        return !string.IsNullOrWhiteSpace(GetToken());
    }

    public async Task<DiscordGuild?> GetGuildAsync(string guildId, bool withCounts = true)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(guildId) || string.IsNullOrWhiteSpace(token)) return null;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        var url = $"https://discord.com/api/v10/guilds/{guildId}" + (withCounts ? "?with_counts=true" : "");
        using var resp = await _http.GetAsync(url);
        if (!resp.IsSuccessStatusCode) return null;
        var json = await resp.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<DiscordGuild>(json);
    }

    public async Task<List<DiscordRole>> GetGuildRolesAsync(string guildId)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(guildId) || string.IsNullOrWhiteSpace(token)) return new List<DiscordRole>();
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        using var resp = await _http.GetAsync($"https://discord.com/api/v10/guilds/{guildId}/roles");
        if (!resp.IsSuccessStatusCode) return new List<DiscordRole>();
        var json = await resp.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<List<DiscordRole>>(json) ?? new List<DiscordRole>();
    }

    public async Task<List<DiscordGuildMember>> GetGuildMembersAsync(string guildId, int pageLimit = 1000, int maxPages = 10)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(guildId) || string.IsNullOrWhiteSpace(token)) return new List<DiscordGuildMember>();
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        var members = new List<DiscordGuildMember>();
        string? after = null;
        for (int i = 0; i < maxPages; i++)
        {
            var url = $"https://discord.com/api/v10/guilds/{guildId}/members?limit={pageLimit}";
            if (!string.IsNullOrWhiteSpace(after)) url += $"&after={after}";
            using var resp = await _http.GetAsync(url);
            if (!resp.IsSuccessStatusCode) break;
            var json = await resp.Content.ReadAsStringAsync();
            var page = JsonSerializer.Deserialize<List<DiscordGuildMember>>(json) ?? new List<DiscordGuildMember>();
            if (page.Count == 0) break;
            members.AddRange(page);
            after = page[^1].user.id;
            if (page.Count < pageLimit) break;
        }
        return members;
    }

    public async Task<List<DiscordGuildMember>> GetMembersWithAnyRoleAsync(string guildId, IEnumerable<string> roleIds)
    {
        var filter = new HashSet<string>(roleIds ?? Array.Empty<string>());
        if (filter.Count == 0) return new List<DiscordGuildMember>();
        var all = await GetGuildMembersAsync(guildId, 1000, 20);
        var res = new List<DiscordGuildMember>();
        foreach (var m in all)
        {
            if (m.roles is null || m.roles.Count == 0) continue;
            foreach (var r in m.roles)
            {
                if (filter.Contains(r))
                {
                    res.Add(m);
                    break;
                }
            }
        }
        return res;
    }
    public async Task<DiscordGuildMember?> GetGuildMemberAsync(string guildId, string userId)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(guildId) || string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(token)) return null;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        using var resp = await _http.GetAsync($"https://discord.com/api/v10/guilds/{guildId}/members/{userId}");
        if (!resp.IsSuccessStatusCode) return null;
        var json = await resp.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<DiscordGuildMember>(json);
    }

    public async Task<DiscordUser?> GetUserAsync(string userId)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(token)) return null;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        using var resp = await _http.GetAsync($"https://discord.com/api/v10/users/{userId}");
        if (!resp.IsSuccessStatusCode) return null;
        var json = await resp.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<DiscordUser>(json);
    }
    public async Task<List<DiscordMessage>> GetChannelMessagesAsync(string channelId, int limit = 50)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(channelId) || string.IsNullOrWhiteSpace(token)) return new List<DiscordMessage>();
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        using var resp = await _http.GetAsync($"https://discord.com/api/v10/channels/{channelId}/messages?limit={limit}");
        if (!resp.IsSuccessStatusCode) return new List<DiscordMessage>();
        var json = await resp.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<List<DiscordMessage>>(json) ?? new List<DiscordMessage>();
    }
    public async Task<bool> SendChannelMessageAsync(string channelId, string content)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(channelId) || string.IsNullOrWhiteSpace(content) || string.IsNullOrWhiteSpace(token)) return false;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        var payload = new { content = content };
        var body = new StringContent(JsonSerializer.Serialize(payload), System.Text.Encoding.UTF8, "application/json");
        using var resp = await _http.PostAsync($"https://discord.com/api/v10/channels/{channelId}/messages", body);
        return resp.IsSuccessStatusCode;
    }
    public async Task<bool> AddRoleToMemberAsync(string guildId, string userId, string roleId)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(guildId) || string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(roleId) || string.IsNullOrWhiteSpace(token)) return false;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        using var req = new HttpRequestMessage(HttpMethod.Put, $"https://discord.com/api/v10/guilds/{guildId}/members/{userId}/roles/{roleId}");
        using var resp = await _http.SendAsync(req);
        return resp.IsSuccessStatusCode;
    }
    public async Task<bool> RemoveRoleFromMemberAsync(string guildId, string userId, string roleId)
    {
        var token = GetToken();
        if (string.IsNullOrWhiteSpace(guildId) || string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(roleId) || string.IsNullOrWhiteSpace(token)) return false;
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bot", token);
        using var req = new HttpRequestMessage(HttpMethod.Delete, $"https://discord.com/api/v10/guilds/{guildId}/members/{userId}/roles/{roleId}");
        using var resp = await _http.SendAsync(req);
        return resp.IsSuccessStatusCode;
    }
    public string GetAvatarUrl(DiscordUser user)
    {
        if (!string.IsNullOrWhiteSpace(user.avatar))
            return $"https://cdn.discordapp.com/avatars/{user.id}/{user.avatar}.png?size=128";
        return "https://cdn.discordapp.com/embed/avatars/0.png";
    }
    public string GetMemberDisplayName(DiscordGuildMember member)
    {
        if (!string.IsNullOrWhiteSpace(member.nick)) return member.nick;
        if (!string.IsNullOrWhiteSpace(member.user.global_name)) return member.user.global_name;
        if (!string.IsNullOrWhiteSpace(member.user.username)) return member.user.username;
        return "Unbekannt";
    }
    public string GetDisplayName(DiscordUser user)
    {
        if (!string.IsNullOrWhiteSpace(user.global_name)) return user.global_name;
        if (!string.IsNullOrWhiteSpace(user.username)) return user.username;
        return "Unbekannt";
    }
}
