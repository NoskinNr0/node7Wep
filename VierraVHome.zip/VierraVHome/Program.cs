using VierraVHome.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OAuth;
using System.Security.Claims;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddSingleton<DiscordService>();
builder.WebHost.UseStaticWebAssets();
builder.WebHost.UseUrls("http://localhost:5002");
var clientId = Environment.GetEnvironmentVariable("DISCORD_CLIENT_ID") ?? "";
var clientSecret = Environment.GetEnvironmentVariable("DISCORD_CLIENT_SECRET") ?? "";
var authEnabled = !string.IsNullOrWhiteSpace(clientId) && !string.IsNullOrWhiteSpace(clientSecret);
if (authEnabled)
{
    builder.Services.AddAuthentication(options =>
    {
        options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = "Discord";
    })
    .AddCookie(options =>
    {
        options.LoginPath = "/signin-discord";
        options.LogoutPath = "/logout";
    })
    .AddOAuth("Discord", options =>
    {
        options.ClientId = clientId;
        options.ClientSecret = clientSecret;
        options.AuthorizationEndpoint = "https://discord.com/api/oauth2/authorize";
        options.TokenEndpoint = "https://discord.com/api/oauth2/token";
        options.UserInformationEndpoint = "https://discord.com/api/users/@me";
        options.CallbackPath = "/signin-discord-callback";
        options.Scope.Add("identify");
        options.SaveTokens = true;
        options.ClaimActions.MapJsonKey(ClaimTypes.NameIdentifier, "id");
        options.ClaimActions.MapJsonKey(ClaimTypes.Name, "global_name");
        options.ClaimActions.MapJsonKey("discord:username", "username");
        options.Events = new OAuthEvents
        {
            OnCreatingTicket = async context =>
            {
                var request = new HttpRequestMessage(System.Net.Http.HttpMethod.Get, context.Options.UserInformationEndpoint);
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", context.AccessToken);
                var response = await context.Backchannel.SendAsync(request);
                var json = await response.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;
                context.RunClaimActions(root);
                if (root.TryGetProperty("id", out var idEl) && root.TryGetProperty("avatar", out var avEl))
                {
                    var id = idEl.GetString() ?? "";
                    var av = avEl.GetString() ?? "";
                    var avatarUrl = string.IsNullOrWhiteSpace(av)
                        ? $"https://cdn.discordapp.com/embed/avatars/0.png"
                        : $"https://cdn.discordapp.com/avatars/{id}/{av}.png?size=64";
                    context.Identity!.AddClaim(new Claim("discord:avatar_url", avatarUrl));
                }
            }
        };
    });
    builder.Services.AddAuthorization();
}
else
{
    builder.Services.AddAuthentication(options =>
    {
        options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    })
    .AddCookie();
}

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

if (authEnabled)
{
    app.MapGet("/signin-discord", async ctx =>
    {
        var props = new AuthenticationProperties { RedirectUri = "/" };
        await ctx.ChallengeAsync("Discord", props);
    }).AllowAnonymous();
}
else
{
    app.MapGet("/signin-discord", async ctx =>
    {
        ctx.Response.StatusCode = StatusCodes.Status302Found;
        ctx.Response.Headers.Location = "/";
    }).AllowAnonymous();
}
app.MapGet("/logout", async ctx =>
{
    await ctx.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
    ctx.Response.Redirect("/");
});

app.Run();
