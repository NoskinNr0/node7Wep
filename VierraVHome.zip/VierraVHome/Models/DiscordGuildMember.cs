namespace VierraVHome.Models;

public class DiscordGuildMember
{
    public DiscordUser user { get; set; } = new DiscordUser();
    public string nick { get; set; } = "";
    public List<string> roles { get; set; } = new List<string>();
}
