namespace VierraVHome.Models;

public class DiscordRole
{
    public string id { get; set; } = "";
    public string name { get; set; } = "";
    public int position { get; set; }
}
