namespace VierraVHome.Models;

public class DiscordGuild
{
    public string id { get; set; } = "";
    public string name { get; set; } = "";
    public string icon { get; set; } = "";
    public string banner { get; set; } = "";
    public int premium_subscription_count { get; set; }
    public int approximate_member_count { get; set; }
    public int approximate_presence_count { get; set; }
}
