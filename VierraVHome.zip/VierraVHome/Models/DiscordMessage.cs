namespace VierraVHome.Models;

public class DiscordMessage
{
    public string id { get; set; } = "";
    public string content { get; set; } = "";
    public DiscordUser author { get; set; } = new DiscordUser();
    public string timestamp { get; set; } = "";
}
