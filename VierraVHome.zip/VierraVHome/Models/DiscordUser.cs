namespace VierraVHome.Models;

public class DiscordUser
{
    public string id { get; set; } = "";
    public string username { get; set; } = "";
    public string global_name { get; set; } = "";
    public string avatar { get; set; } = "";
}
